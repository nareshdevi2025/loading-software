import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calendar, Download, BarChart3, Package, Clock, CheckCircle, Users } from "lucide-react";
import { format, startOfDay, endOfDay, parseISO } from "date-fns";

export default function DailyReport({ selectedDate, onDateChange, onBack, sessions }) {
  const [dailySessions, setDailySessions] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    completed: 0,
    inProgress: 0,
    totalDuration: 0,
    totalProducts: 0,
    totalPallets: 0,
    totalQuantity: 0
  });

  useEffect(() => {
    generateDailyReport();
  }, [selectedDate, sessions]);

  const generateDailyReport = () => {
    const targetDate = parseISO(selectedDate);
    const dayStart = startOfDay(targetDate);
    const dayEnd = endOfDay(targetDate);

    const filtered = sessions.filter(session => {
      const sessionDate = new Date(session.created_date);
      return sessionDate >= dayStart && sessionDate <= dayEnd;
    });

    setDailySessions(filtered);

    // Calculate statistics
    const newStats = {
      total: filtered.length,
      completed: filtered.filter(s => s.status === 'completed').length,
      inProgress: filtered.filter(s => s.status === 'in_progress').length,
      totalDuration: filtered.reduce((sum, s) => sum + (s.duration_minutes || 0), 0),
      totalProducts: filtered.reduce((sum, s) => sum + (s.products?.length || 0), 0),
      totalPallets: filtered.reduce((sum, s) => sum + (s.pallets?.length || 0), 0),
      totalQuantity: filtered.reduce((sum, s) => 
        sum + (s.pallets?.reduce((palletSum, p) => palletSum + (p.quantity || 0), 0) || 0), 0
      )
    };

    setStats(newStats);
  };

  const exportDailyReport = () => {
    const reportData = [
      ['DAILY LOADING REPORT'],
      [`Date: ${format(parseISO(selectedDate), 'dd MMM yyyy')}`],
      [''],
      ['SUMMARY'],
      ['Total Sessions', stats.total],
      ['Completed Sessions', stats.completed],
      ['In Progress Sessions', stats.inProgress],
      ['Total Duration (minutes)', stats.totalDuration],
      ['Total Products Loaded', stats.totalProducts],
      ['Total Pallets', stats.totalPallets],
      ['Total Quantity', stats.totalQuantity],
      [''],
      ['SESSION DETAILS'],
      ['Time', 'Session ID', 'Party', 'Vehicle', 'Status', 'Duration', 'Products', 'Pallets', 'Quantity'],
      ...dailySessions.map(session => [
        format(new Date(session.created_date), 'HH:mm'),
        session.session_id || '',
        session.party_name || '',
        session.vehicle_number || '',
        session.status || '',
        session.duration_minutes || 0,
        session.products?.length || 0,
        session.pallets?.length || 0,
        session.pallets?.reduce((sum, p) => sum + (p.quantity || 0), 0) || 0
      ])
    ];

    const csvContent = reportData
      .map(row => Array.isArray(row) ? row.map(field => `"${field}"`).join(',') : `"${row}"`)
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `daily-report-${selectedDate}.csv`;
    a.click();
  };

  // Group sessions by hour for better visualization
  const sessionsByHour = dailySessions.reduce((acc, session) => {
    const hour = format(new Date(session.created_date), 'HH:00');
    if (!acc[hour]) acc[hour] = [];
    acc[hour].push(session);
    return acc;
  }, {});

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="icon" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-slate-900">Daily Loading Report</h1>
            <p className="text-slate-600">Detailed analysis for {format(parseISO(selectedDate), 'dd MMMM yyyy')}</p>
          </div>
          <div className="flex gap-3">
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => onDateChange(e.target.value)}
              className="w-40"
            />
            <Button 
              variant="outline" 
              onClick={exportDailyReport}
              disabled={dailySessions.length === 0}
            >
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-blue-200 bg-blue-50/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600 mb-1">Total Sessions</p>
                  <p className="text-3xl font-bold text-slate-900">{stats.total}</p>
                </div>
                <BarChart3 className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-green-50/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600 mb-1">Completed</p>
                  <p className="text-3xl font-bold text-slate-900">{stats.completed}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-200 bg-purple-50/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600 mb-1">Total Duration</p>
                  <p className="text-3xl font-bold text-slate-900">{Math.floor(stats.totalDuration / 60)}h {stats.totalDuration % 60}m</p>
                </div>
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-orange-200 bg-orange-50/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600 mb-1">Total Quantity</p>
                  <p className="text-3xl font-bold text-slate-900">{stats.totalQuantity}</p>
                </div>
                <Package className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Breakdown */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Loading Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Products Loaded:</span>
                  <span className="font-bold">{stats.totalProducts}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Pallets Used:</span>
                  <span className="font-bold">{stats.totalPallets}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Avg Session Duration:</span>
                  <span className="font-bold">
                    {stats.total > 0 ? Math.round(stats.totalDuration / stats.total) : 0}m
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Success Rate:</span>
                  <span className="font-bold text-green-600">
                    {stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0}%
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Status Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span>Completed</span>
                  </div>
                  <span className="font-bold">{stats.completed}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                    <span>In Progress</span>
                  </div>
                  <span className="font-bold">{stats.inProgress}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-slate-400 rounded-full"></div>
                    <span>Not Started</span>
                  </div>
                  <span className="font-bold">{stats.total - stats.completed - stats.inProgress}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Performance Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-slate-600">Completion Rate</span>
                    <span className="text-sm font-medium">
                      {stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full transition-all"
                      style={{ width: `${stats.total > 0 ? (stats.completed / stats.total) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-slate-600">Efficiency Score</span>
                    <span className="text-sm font-medium">
                      {stats.totalDuration > 0 ? Math.round((stats.totalQuantity / stats.totalDuration) * 10) : 0}/10
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded-full transition-all"
                      style={{ width: `${Math.min(100, stats.totalDuration > 0 ? (stats.totalQuantity / stats.totalDuration) * 100 : 0)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Hourly Sessions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Sessions Timeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            {dailySessions.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No sessions found for this date</p>
                <p className="text-sm text-slate-400">Try selecting a different date</p>
              </div>
            ) : (
              <div className="space-y-4">
                {Object.entries(sessionsByHour)
                  .sort(([a], [b]) => a.localeCompare(b))
                  .map(([hour, hourSessions]) => (
                  <div key={hour} className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      {hour} ({hourSessions.length} sessions)
                    </h4>
                    <div className="grid gap-3">
                      {hourSessions.map((session) => (
                        <div key={session.id} className="flex items-center justify-between p-3 bg-slate-50 rounded">
                          <div className="flex items-center gap-3">
                            <span className="text-sm font-mono">
                              {format(new Date(session.created_date), 'HH:mm')}
                            </span>
                            <span className="font-medium">{session.party_name}</span>
                            <span className="text-sm text-slate-600">{session.vehicle_number}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge 
                              className={
                                session.status === 'completed' ? 'bg-green-100 text-green-800' :
                                session.status === 'in_progress' ? 'bg-orange-100 text-orange-800' :
                                'bg-slate-100 text-slate-800'
                              }
                            >
                              {session.status}
                            </Badge>
                            <span className="text-sm text-slate-600">
                              {session.pallets?.reduce((sum, p) => sum + (p.quantity || 0), 0) || 0} qty
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}