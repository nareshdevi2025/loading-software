import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Square, Clock } from "lucide-react";
import { format } from "date-fns";

export default function LoadingTimer({ session, onStart, onEnd, canStart }) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setCurrentTime(now);
      
      if (session.status === "in_progress" && session.start_time) {
        const startTime = new Date(session.start_time);
        const diff = Math.floor((now - startTime) / 1000);
        setDuration(diff);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [session.status, session.start_time]);

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getStatusBadge = () => {
    switch (session.status) {
      case "in_progress":
        return <Badge className="bg-green-100 text-green-800 border-green-200">Loading in Progress</Badge>;
      case "completed":
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Completed</Badge>;
      default:
        return <Badge variant="outline" className="border-slate-300">Ready to Start</Badge>;
    }
  };

  return (
    <Card className="shadow-sm border-blue-200 bg-blue-50/30">
      <CardHeader className="border-b border-blue-200/50">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-600" />
            Loading Timer
          </CardTitle>
          {getStatusBadge()}
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="grid md:grid-cols-3 gap-6 mb-6">
          <div className="text-center p-4 bg-white rounded-lg border border-slate-200">
            <p className="text-sm font-medium text-slate-600 mb-2">Current Time</p>
            <p className="text-2xl font-mono font-bold text-slate-900">
              {format(currentTime, "HH:mm:ss")}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {format(currentTime, "dd MMM yyyy")}
            </p>
          </div>
          
          <div className="text-center p-4 bg-white rounded-lg border border-slate-200">
            <p className="text-sm font-medium text-slate-600 mb-2">Start Time</p>
            <p className="text-2xl font-mono font-bold text-slate-900">
              {session.start_time ? format(new Date(session.start_time), "HH:mm:ss") : "--:--:--"}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {session.start_time ? format(new Date(session.start_time), "dd MMM yyyy") : "Not started"}
            </p>
          </div>

          <div className="text-center p-4 bg-white rounded-lg border border-slate-200">
            <p className="text-sm font-medium text-slate-600 mb-2">Duration</p>
            <p className="text-2xl font-mono font-bold text-blue-600">
              {formatDuration(duration)}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {duration > 0 && `${Math.floor(duration / 60)} minutes`}
            </p>
          </div>
        </div>

        <div className="flex justify-center gap-4">
          {session.status === "not_started" && (
            <Button 
              onClick={onStart}
              disabled={!canStart}
              className="bg-green-600 hover:bg-green-700 px-8 py-3 text-base"
            >
              <Play className="w-5 h-5 mr-2" />
              Start Loading
            </Button>
          )}
          
          {session.status === "in_progress" && (
            <Button 
              onClick={onEnd}
              className="bg-red-600 hover:bg-red-700 px-8 py-3 text-base"
            >
              <Square className="w-5 h-5 mr-2" />
              End Loading
            </Button>
          )}
        </div>

        {!canStart && session.status === "not_started" && (
          <div className="text-center mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              Complete party, vehicle, and product details to start loading
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}