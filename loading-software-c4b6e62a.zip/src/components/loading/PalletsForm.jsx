
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Grid3X3, Plus, Trash2, Package } from "lucide-react";

export default function PalletsForm({ session, onUpdate, disabled }) {
  const addPallet = () => {
    const palletNumber = `Pallet ${session.pallets.length + 1}`;
    const newPallets = [...session.pallets, { 
      pallet_number: palletNumber, 
      length: 0, 
      width: 0,
      loose_quantity: 0,
      quantity: 0,
      product_name: "" // Set to empty, forcing user to select
    }];
    onUpdate({ pallets: newPallets });
  };

  const updatePallet = (index, field, value) => {
    const newPallets = [...session.pallets];
    const updatedPallet = { ...newPallets[index] };

    if (field === 'product_name' || field === 'pallet_number') {
        updatedPallet[field] = value;
    } else {
        updatedPallet[field] = parseInt(value, 10) || 0;
    }

    const length = updatedPallet.length || 0;
    const width = updatedPallet.width || 0;
    const loose_quantity = updatedPallet.loose_quantity || 0;
    updatedPallet.quantity = (length * width) + loose_quantity;
    
    newPallets[index] = updatedPallet;
    onUpdate({ pallets: newPallets });
  };

  const removePallet = (index) => {
    const newPallets = session.pallets.filter((_, i) => i !== index);
    onUpdate({ pallets: newPallets });
  };

  // Group pallets by product for better visualization
  const palletsByProduct = session.pallets.reduce((acc, pallet, index) => {
    const productName = pallet.product_name || "Unassigned";
    if (!acc[productName]) {
      acc[productName] = [];
    }
    acc[productName].push({ ...pallet, originalIndex: index });
    return acc;
  }, {});

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <Grid3X3 className="w-5 h-5 text-blue-600" />
            Pallet Details
          </CardTitle>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={addPallet}
            disabled={disabled || session.products.length === 0}
          >
            <Plus className="w-4 h-4 mr-1" />
            Add Pallet
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {session.pallets.length === 0 ? (
          <div className="text-center py-6 text-slate-500">
            <Grid3X3 className="w-8 h-8 mx-auto mb-2 text-slate-300" />
            <p>No pallets added yet</p>
            <p className="text-sm">Add products first, then add pallets</p>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(palletsByProduct).map(([productName, pallets]) => (
              <div key={productName} className="border rounded-lg p-4 bg-slate-50">
                <div className="flex items-center gap-2 mb-4">
                  <Package className="w-4 h-4 text-blue-600" />
                  <h4 className="font-semibold text-slate-900">{productName}</h4>
                  <span className="text-sm text-slate-600">
                    ({pallets.reduce((sum, pallet) => sum + pallet.quantity, 0)} total qty)
                  </span>
                </div>
                
                <div className="space-y-3">
                  {pallets.map((pallet) => (
                    <div key={pallet.originalIndex} className="p-3 border rounded-lg bg-white">
                      <div className="grid grid-cols-1 md:grid-cols-6 gap-3 items-end">
                        <div>
                          <Label className="text-xs">Pallet #</Label>
                          <Input
                            value={pallet.pallet_number}
                            onChange={(e) => updatePallet(pallet.originalIndex, "pallet_number", e.target.value)}
                            disabled={disabled}
                            className="h-8 text-sm"
                          />
                        </div>
                        
                        <div>
                          <Label className="text-xs">Length</Label>
                          <Input
                            type="number"
                            min="0"
                            value={pallet.length}
                            onChange={(e) => updatePallet(pallet.originalIndex, "length", e.target.value)}
                            disabled={disabled}
                            className="h-8 text-sm"
                          />
                        </div>
                        
                        <div>
                          <Label className="text-xs">Width</Label>
                          <Input
                            type="number"
                            min="0"
                            value={pallet.width}
                            onChange={(e) => updatePallet(pallet.originalIndex, "width", e.target.value)}
                            disabled={disabled}
                            className="h-8 text-sm"
                          />
                        </div>

                        <div>
                          <Label className="text-xs">Loose Qty</Label>
                          <Input
                            type="number"
                            min="0"
                            value={pallet.loose_quantity || 0}
                            onChange={(e) => updatePallet(pallet.originalIndex, "loose_quantity", e.target.value)}
                            disabled={disabled}
                            className="h-8 text-sm"
                          />
                        </div>
                        
                        <div>
                          <Label className="text-xs">Total Qty</Label>
                          <div className="flex items-center gap-1">
                            <Input
                              type="number"
                              value={pallet.quantity}
                              readOnly
                              className="bg-green-50 border-green-200 h-8 text-sm font-medium"
                            />
                            <span className="text-xs text-slate-600">nos</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <div className="flex-1">
                            <Label className="text-xs">Product</Label>
                            <Select 
                              value={pallet.product_name || ""} 
                              onValueChange={(value) => updatePallet(pallet.originalIndex, "product_name", value)}
                              disabled={disabled}
                            >
                              <SelectTrigger className="h-8 text-sm">
                                <SelectValue placeholder="Select product" />
                              </SelectTrigger>
                              <SelectContent>
                                {session.products.filter(product => product.product_name && product.product_name.trim() !== "").map((product, prodIndex) => (
                                  <SelectItem key={prodIndex} value={product.product_name}>
                                    {product.product_name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => removePallet(pallet.originalIndex)}
                            disabled={disabled}
                            className="h-8 w-8 text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            
            <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="font-semibold mb-3 text-blue-900">Loading Summary:</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="text-center p-3 bg-white rounded border">
                  <span className="text-slate-600 block">Total Pallets</span>
                  <span className="text-2xl font-bold text-blue-600">{session.pallets.length}</span>
                </div>
                <div className="text-center p-3 bg-white rounded border">
                  <span className="text-slate-600 block">Total Quantity</span>
                  <span className="text-2xl font-bold text-green-600">
                    {session.pallets.reduce((sum, pallet) => sum + pallet.quantity, 0)}
                  </span>
                </div>
                <div className="text-center p-3 bg-white rounded border">
                  <span className="text-slate-600 block">Products</span>
                  <span className="text-2xl font-bold text-purple-600">
                    {Object.keys(palletsByProduct).length}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
