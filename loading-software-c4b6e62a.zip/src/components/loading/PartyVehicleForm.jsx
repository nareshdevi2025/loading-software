import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2, Truck, Users } from "lucide-react";

export default function PartyVehicleForm({ session, options, onUpdate, disabled }) {
  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building2 className="w-5 h-5 text-blue-600" />
          Party & Vehicle Details
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="party">Party Name *</Label>
          <Select 
            value={session.party_name || ""} 
            onValueChange={(value) => onUpdate({ party_name: value })}
            disabled={disabled}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select or enter party name" />
            </SelectTrigger>
            <SelectContent>
              {options.parties.filter(party => party.option_value && party.option_value.trim() !== "").map((party) => (
                <SelectItem key={party.id} value={party.option_value}>
                  {party.option_value}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="vehicle">Vehicle Number *</Label>
          <Select 
            value={session.vehicle_number || ""} 
            onValueChange={(value) => onUpdate({ vehicle_number: value })}
            disabled={disabled}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select vehicle number" />
            </SelectTrigger>
            <SelectContent>
              {options.vehicles.filter(vehicle => vehicle.option_value && vehicle.option_value.trim() !== "").map((vehicle) => (
                <SelectItem key={vehicle.id} value={vehicle.option_value}>
                  {vehicle.option_value}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="persons">Number of Loading Persons</Label>
          <div className="flex items-center gap-3">
            <Users className="w-5 h-5 text-slate-400" />
            <Input
              type="number"
              min="1"
              value={session.loading_persons_count}
              onChange={(e) => onUpdate({ loading_persons_count: parseInt(e.target.value) || 1 })}
              disabled={disabled}
              className="w-24"
            />
            <span className="text-sm text-slate-600">persons</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}