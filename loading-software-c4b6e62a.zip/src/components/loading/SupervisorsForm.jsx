import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserCheck, Plus, X } from "lucide-react";

export default function SupervisorsForm({ session, options, onUpdate, disabled }) {
  const addSupervisor = (supervisor) => {
    if (!session.supervisors.includes(supervisor)) {
      const newSupervisors = [...session.supervisors, supervisor];
      onUpdate({ supervisors: newSupervisors });
    }
  };

  const removeSupervisor = (supervisorToRemove) => {
    const newSupervisors = session.supervisors.filter(sup => sup !== supervisorToRemove);
    onUpdate({ supervisors: newSupervisors });
  };

  const availableSupervisors = options.supervisors.filter(
    supervisor => supervisor.option_value && 
                 supervisor.option_value.trim() !== "" &&
                 !session.supervisors.includes(supervisor.option_value)
  );

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserCheck className="w-5 h-5 text-blue-600" />
          Loading Supervisors
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!disabled && (
          <div className="flex gap-2">
            <Select onValueChange={addSupervisor}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Add supervisor" />
              </SelectTrigger>
              <SelectContent>
                {availableSupervisors.map((supervisor) => (
                  <SelectItem key={supervisor.id} value={supervisor.option_value}>
                    {supervisor.option_value}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {session.supervisors.length === 0 ? (
          <div className="text-center py-6 text-slate-500">
            <UserCheck className="w-8 h-8 mx-auto mb-2 text-slate-300" />
            <p>No supervisors assigned</p>
            <p className="text-sm">Select supervisors from the dropdown</p>
          </div>
        ) : (
          <div className="space-y-2">
            <h4 className="font-medium text-slate-700">Assigned Supervisors:</h4>
            <div className="flex flex-wrap gap-2">
              {session.supervisors.map((supervisor, index) => (
                <Badge key={index} variant="secondary" className="flex items-center gap-1">
                  {supervisor}
                  {!disabled && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeSupervisor(supervisor)}
                      className="h-4 w-4 p-0 hover:bg-transparent"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  )}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}