import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Package, Plus, Trash2, CheckCircle, Search } from "lucide-react";

export default function ProductsForm({ session, options, onUpdate, disabled }) {
  const [searchTerm, setSearchTerm] = useState("");

  const addProduct = () => {
    const newProducts = [...session.products, { product_name: "", total_quantity: 0, unit: "pcs", status: "pending" }];
    onUpdate({ products: newProducts });
  };

  const updateProduct = (index, field, value) => {
    const newProducts = [...session.products];
    newProducts[index] = { ...newProducts[index], [field]: value };
    onUpdate({ products: newProducts });
  };

  const removeProduct = (index) => {
    const productToRemove = session.products[index];
    const newProducts = session.products.filter((_, i) => i !== index);
    
    // Remove associated pallets
    const newPallets = session.pallets.filter(pallet => pallet.product_name !== productToRemove.product_name);
    
    onUpdate({ products: newProducts, pallets: newPallets });
  };

  const markProductComplete = (index) => {
    const newProducts = [...session.products];
    newProducts[index] = { 
      ...newProducts[index], 
      status: newProducts[index].status === "completed" ? "pending" : "completed"
    };
    onUpdate({ products: newProducts });
  };

  // Calculate loaded quantity from pallets for each product
  const getLoadedQuantity = (productName) => {
    return session.pallets
      .filter(pallet => pallet.product_name === productName)
      .reduce((sum, pallet) => sum + (pallet.quantity || 0), 0);
  };

  // Filter products based on search term
  const filteredProducts = options.products.filter(product => 
    product.option_value && 
    product.option_value.trim() !== "" &&
    product.option_value.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <Package className="w-5 h-5 text-blue-600" />
            Products Loading
          </CardTitle>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={addProduct}
            disabled={disabled}
          >
            <Plus className="w-4 h-4 mr-1" />
            Add Product
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {session.products.length === 0 ? (
          <div className="text-center py-6 text-slate-500">
            <Package className="w-8 h-8 mx-auto mb-2 text-slate-300" />
            <p>No products added yet</p>
            <p className="text-sm">Click "Add Product" to start</p>
          </div>
        ) : (
          <div className="space-y-4">
            {session.products.map((product, index) => {
              const loadedQty = getLoadedQuantity(product.product_name);
              const isCompleted = product.status === "completed";
              const palletCount = session.pallets.filter(p => p.product_name === product.product_name).length;
              
              return (
                <div key={index} className={`p-4 border rounded-lg transition-all ${
                  isCompleted ? "bg-green-50 border-green-200" : "bg-slate-50 border-slate-200"
                }`}>
                  <div className="flex flex-col gap-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="flex-grow">
                        <Label className="text-sm font-medium">Product Name</Label>
                        <div className="space-y-2">
                          {/* Search input */}
                          <div className="relative">
                            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                            <Input
                              placeholder="Search products..."
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                              className="pl-10 text-sm"
                              disabled={disabled || isCompleted}
                            />
                          </div>
                          <Select 
                            value={product.product_name || ""} 
                            onValueChange={(value) => updateProduct(index, "product_name", value)}
                            disabled={disabled || isCompleted}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="Select product" />
                            </SelectTrigger>
                            <SelectContent>
                              {filteredProducts.map((prod) => (
                                <SelectItem key={prod.id} value={prod.option_value}>
                                  {prod.option_value}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      <div>
                        <Label className="text-sm font-medium">Target Quantity</Label>
                        <Input
                          type="number"
                          min="0"
                          value={product.total_quantity || 0}
                          onChange={(e) => updateProduct(index, "total_quantity", parseInt(e.target.value) || 0)}
                          disabled={disabled || isCompleted}
                          className="mt-1"
                          placeholder="Enter quantity"
                        />
                      </div>
                      
                      <div>
                        <Label className="text-sm font-medium">Unit</Label>
                        <Select 
                          value={product.unit || "pcs"} 
                          onValueChange={(value) => updateProduct(index, "unit", value)}
                          disabled={disabled || isCompleted}
                        >
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pcs">Pieces</SelectItem>
                            <SelectItem value="kg">Kilograms</SelectItem>
                            <SelectItem value="tons">Tons</SelectItem>
                            <SelectItem value="boxes">Boxes</SelectItem>
                            <SelectItem value="pallets">Pallets</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row gap-2 justify-between items-start sm:items-center">
                      <div className="flex gap-2">
                        <Button 
                          variant={isCompleted ? "default" : "outline"}
                          size="sm"
                          onClick={() => markProductComplete(index)}
                          disabled={disabled}
                          className={isCompleted ? "bg-green-600 hover:bg-green-700" : ""}
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          {isCompleted ? "Completed" : "Mark Complete"}
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => removeProduct(index)}
                          disabled={disabled}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Remove
                        </Button>
                      </div>
                      
                      <div className="text-sm text-slate-600">
                        {palletCount} pallets • Target: {product.total_quantity || 0} {product.unit}
                      </div>
                    </div>
                  </div>
                  
                  {/* Loading Progress */}
                  <div className="mt-4 p-3 bg-white border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Loading Progress</span>
                      <span className="text-sm text-slate-600">
                        {loadedQty} / {product.total_quantity || 0} {product.unit}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex-1">
                        <div className="w-full bg-slate-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full transition-all ${
                              loadedQty >= (product.total_quantity || 0) ? "bg-green-500" : "bg-blue-500"
                            }`}
                            style={{ 
                              width: `${Math.min(100, (loadedQty / Math.max(product.total_quantity || 1, 1)) * 100)}%` 
                            }}
                          ></div>
                        </div>
                      </div>
                      <div className={`px-2 py-1 rounded text-xs font-medium ${
                        loadedQty >= (product.total_quantity || 0)
                          ? "bg-green-100 text-green-800" 
                          : "bg-blue-100 text-blue-800"
                      }`}>
                        {loadedQty >= (product.total_quantity || 0) ? "Complete" : "In Progress"}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}