import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { FileText, Package, Grid3X3, Users, Target } from "lucide-react";

export default function SessionSummary({ session, onUpdate }) {
  const totalPalletQuantity = session.pallets.reduce((sum, pallet) => sum + (pallet.quantity || 0), 0);
  
  const totalTargetQuantity = session.products.reduce((sum, product) => {
    const quantity = Number(product.total_quantity);
    return sum + (isNaN(quantity) ? 0 : quantity);
  }, 0);

  return (
    <Card className="shadow-sm bg-slate-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-600" />
          Session Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-white rounded-lg">
            <Package className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-slate-900">{session.products.length}</p>
            <p className="text-sm text-slate-600">Products</p>
          </div>
          
          <div className="text-center p-4 bg-white rounded-lg">
            <Grid3X3 className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-slate-900">{session.pallets.length}</p>
            <p className="text-sm text-slate-600">Pallets</p>
          </div>
          
          <div className="text-center p-4 bg-white rounded-lg">
            <Target className="w-8 h-8 text-purple-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-slate-900">{totalTargetQuantity}</p>
            <p className="text-sm text-slate-600">Target Qty</p>
          </div>
          
          <div className="text-center p-4 bg-white rounded-lg">
            <Users className="w-8 h-8 text-orange-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-slate-900">{session.supervisors.length}</p>
            <p className="text-sm text-slate-600">Supervisors</p>
          </div>
        </div>

        {session.products.length > 0 && (
          <div className="bg-white p-4 rounded-lg">
            <h4 className="font-semibold mb-3">Product Summary:</h4>
            <div className="space-y-3">
              {session.products.map((product, index) => {
                const loadedQty = product.product_name
                  ? session.pallets
                      .filter(p => p.product_name === product.product_name)
                      .reduce((sum, p) => sum + (Number(p.quantity) || 0), 0)
                  : 0;
                
                const targetQty = Number(product.total_quantity) || 0;
                const productName = product.product_name || "Not specified";

                return (
                  <div key={index} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                    <div>
                      <span className="font-medium">{productName}</span>
                      <p className="text-sm text-slate-600">
                        Target: {targetQty} {product.unit} • 
                        Loaded: {loadedQty} {product.unit}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-green-600">
                        {loadedQty} / {targetQty}
                      </span>
                      <p className="text-xs text-slate-500">{product.unit}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div>
          <Label htmlFor="notes">Additional Notes</Label>
          <Textarea
            id="notes"
            placeholder="Add any additional notes about this loading session..."
            value={session.notes || ""}
            onChange={(e) => onUpdate && onUpdate({ notes: e.target.value })}
            disabled={session.status === "completed"}
            className="mt-1"
          />
        </div>
      </CardContent>
    </Card>
  );
}