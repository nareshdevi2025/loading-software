
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, Clock, CheckCircle, Timer, Calendar } from "lucide-react"; // Added Calendar
import { Skeleton } from "@/components/ui/skeleton";

export default function StatsOverview({ 
  totalSessions, 
  activeSessions, 
  completedToday, 
  avgDuration, 
  plannedSessions = 0, // Added plannedSessions prop with default value
  isLoading 
}) {
  const formatAvgDuration = (minutes) => {
    if (isNaN(minutes) || minutes <= 0) {
      return "0m";
    }
    const hours = Math.floor(minutes / 60);
    const mins = Math.round(minutes % 60);
    let result = '';
    if (hours > 0) {
      result += `${hours}h `;
    }
    result += `${mins}m`;
    return result.trim(); // Use trim to remove trailing space if only minutes
  };

  const stats = [
    {
      title: "Total Sessions",
      value: totalSessions,
      icon: Package,
      bgColor: "bg-blue-50",
      iconColor: "text-blue-600",
      borderColor: "border-blue-200"
    },
    {
      title: "Active Loading",
      value: activeSessions,
      icon: Timer,
      bgColor: "bg-orange-50",
      iconColor: "text-orange-600",
      borderColor: "border-orange-200"
    },
    {
      title: "Completed Today",
      value: completedToday,
      icon: CheckCircle,
      bgColor: "bg-green-50",
      iconColor: "text-green-600",
      borderColor: "border-green-200"
    },
    {
      title: "Planned Sessions", // Changed from "Avg Duration"
      value: plannedSessions, // Uses plannedSessions prop
      icon: Calendar, // Changed icon to Calendar
      bgColor: "bg-purple-50",
      iconColor: "text-purple-600",
      borderColor: "border-purple-200"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat) => (
        <Card key={stat.title} className={`border ${stat.borderColor} ${stat.bgColor} hover:shadow-md transition-shadow`}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-600 mb-1">{stat.title}</p>
                {isLoading ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <p className="text-3xl font-bold text-slate-900">
                    {stat.value}
                  </p>
                )}
              </div>
              <div className={`p-3 rounded-full ${stat.bgColor} border ${stat.borderColor}`}>
                <stat.icon className={`w-6 h-6 ${stat.iconColor}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
