
import React, { useState, useEffect } from "react";
import { LoadingSession } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, CheckCircle, Clock, AlertTriangle, Package, Grid3X3 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function Verification() {
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [verificationItems, setVerificationItems] = useState([]);
  const [completionNotes, setCompletionNotes] = useState("");
  const [isCompleting, setIsCompleting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [liveTime, setLiveTime] = useState(new Date()); // State for live time to update duration

  useEffect(() => {
    loadSession();

    // Set up interval to update live time every second
    const timer = setInterval(() => {
      setLiveTime(new Date());
    }, 1000);

    // Cleanup interval on component unmount
    return () => clearInterval(timer);
  }, []);

  const loadSession = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session');
    
    if (sessionId) {
      const sessionData = await LoadingSession.list();
      const foundSession = sessionData.find(s => s.id === sessionId);
      if (foundSession) {
        setSession(foundSession);
        initializeVerificationItems(foundSession);
      }
    }
    setIsLoading(false);
  };

  const initializeVerificationItems = (sessionData) => {
    const items = [
      {
        id: "vehicle_check",
        label: "Vehicle condition verified",
        description: "Check vehicle is suitable and ready for loading",
        checked: false,
        required: true
      },
      {
        id: "products_match",
        label: "All products match specifications",
        description: "Verify product quality and specifications",
        checked: false,
        required: true
      },
      {
        id: "quantities_correct",
        label: "Quantities are correct as per order",
        description: "Cross-check loaded quantities with requirements",
        checked: false,
        required: true
      },
      {
        id: "pallets_secured",
        label: "All pallets properly secured",
        description: "Ensure pallets are safely loaded and secured",
        checked: false,
        required: true
      },
      {
        id: "documentation_complete",
        label: "Loading documentation complete",
        description: "All paperwork and records are properly filled",
        checked: false,
        required: true
      },
      {
        id: "safety_check",
        label: "Safety protocols followed",
        description: "All safety measures were properly implemented",
        checked: false,
        required: true
      }
    ];
    setVerificationItems(items);
  };

  const updateVerificationItem = (itemId, checked) => {
    setVerificationItems(prev => 
      prev.map(item => 
        item.id === itemId ? { ...item, checked } : item
      )
    );
  };

  const completeLoading = async () => {
    setIsCompleting(true);
    
    const endTime = new Date();
    const startTime = new Date(session.start_time);
    const duration = Math.round((endTime - startTime) / (1000 * 60));

    await LoadingSession.update(session.id, {
      end_time: endTime.toISOString(),
      duration_minutes: duration,
      status: "completed",
      notes: completionNotes,
      verification_checklist: verificationItems
    });

    navigate(createPageUrl(`Billing?session=${session.id}`));
  };

  const allRequiredItemsChecked = verificationItems
    .filter(item => item.required)
    .every(item => item.checked);

  if (isLoading || !session) {
    return (
      <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-slate-200 rounded w-1/3"></div>
            <div className="h-64 bg-slate-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  // Use liveTime for dynamic duration calculation
  const startTime = new Date(session.start_time);
  const currentDuration = Math.round((liveTime - startTime) / (1000 * 60));

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Verification & Completion</h1>
            <p className="text-slate-600 mt-1">Verify loading details and complete the session</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Session Overview */}
          <Card className="shadow-sm border-blue-200 bg-blue-50/30">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  Loading Session Overview
                </CardTitle>
                <Badge className="bg-orange-100 text-orange-800">In Progress</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div>
                    <span className="text-sm text-slate-600">Party:</span>
                    <span className="ml-2 font-semibold">{session.party_name}</span>
                  </div>
                  <div>
                    <span className="text-sm text-slate-600">Vehicle:</span>
                    <span className="ml-2 font-semibold">{session.vehicle_number}</span>
                  </div>
                  <div>
                    <span className="text-sm text-slate-600">Session ID:</span>
                    <span className="ml-2 font-semibold">{session.session_id}</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm text-slate-600">Start Time:</span>
                    <span className="ml-2 font-semibold">
                      {format(new Date(session.start_time), "dd MMM yyyy, HH:mm:ss")}
                    </span>
                  </div>
                  <div>
                    <span className="text-sm text-slate-600">Duration:</span>
                    <span className="ml-2 font-semibold text-blue-600">
                      {Math.floor(currentDuration / 60)}h {currentDuration % 60}m
                    </span>
                  </div>
                  <div>
                    <span className="text-sm text-slate-600">Loading Persons:</span>
                    <span className="ml-2 font-semibold">{session.loading_persons_count}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Loading Summary */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="w-5 h-5 text-green-600" />
                  Products Loaded
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {session.products?.map((product, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                      <div>
                        <span className="font-medium">{product.product_name}</span>
                        <p className="text-sm text-slate-600">{product.unit}</p>
                      </div>
                      <span className="font-bold text-green-600">
                        {product.total_quantity}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Grid3X3 className="w-5 h-5 text-purple-600" />
                  Pallets Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <span className="text-3xl font-bold text-purple-600">
                      {session.pallets?.length || 0}
                    </span>
                    <p className="text-sm text-slate-600">Total Pallets</p>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <span className="text-3xl font-bold text-blue-600">
                      {session.pallets?.reduce((sum, pallet) => sum + pallet.quantity, 0) || 0}
                    </span>
                    <p className="text-sm text-slate-600">Total Quantity</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Verification Checklist */}
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Verification Checklist
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {verificationItems.map((item) => (
                  <div key={item.id} className="flex items-start gap-3 p-3 border rounded-lg">
                    <Checkbox
                      id={item.id}
                      checked={item.checked}
                      onCheckedChange={(checked) => updateVerificationItem(item.id, checked)}
                    />
                    <div className="flex-1">
                      <label htmlFor={item.id} className="font-medium cursor-pointer">
                        {item.label}
                        {item.required && <span className="text-red-500 ml-1">*</span>}
                      </label>
                      <p className="text-sm text-slate-600 mt-1">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Completion Notes */}
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle>Completion Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <Label htmlFor="completion-notes">Additional notes or observations</Label>
              <Textarea
                id="completion-notes"
                placeholder="Add any final notes about the loading process, issues encountered, or recommendations..."
                value={completionNotes}
                onChange={(e) => setCompletionNotes(e.target.value)}
                className="mt-2"
                rows={4}
              />
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex justify-end gap-4 pb-8">
            <Button
              variant="outline"
              onClick={() => navigate(createPageUrl("Dashboard"))}
            >
              Cancel
            </Button>
            <Button
              onClick={completeLoading}
              disabled={!allRequiredItemsChecked || isCompleting}
              className="bg-green-600 hover:bg-green-700 px-8"
            >
              {isCompleting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Completing...
                </>
              ) : (
                <>
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Complete Loading Session
                </>
              )}
            </Button>
          </div>

          {!allRequiredItemsChecked && (
            <div className="flex items-center gap-2 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-yellow-600" />
              <p className="text-sm text-yellow-800">
                Please complete all required verification items before finishing the loading session.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
