import React, { useState, useEffect } from "react";
import { Company } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Building2, Plus, Edit, Trash2, Search, Filter, Phone, Mail, MapPin, CreditCard } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function CompanyMasterPage() {
  const [companies, setCompanies] = useState([]);
  const [filteredCompanies, setFilteredCompanies] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingCompany, setEditingCompany] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [formData, setFormData] = useState({
    company_name: "",
    company_code: "",
    contact_person: "",
    phone_number: "",
    email: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    gst_number: "",
    pan_number: "",
    company_type: "client",
    is_active: true,
    credit_limit: 0,
    payment_terms: "",
    notes: ""
  });

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterCompanies();
  }, [companies, searchTerm, typeFilter]);

  const loadData = async () => {
    setIsLoading(true);
    const [companiesData, user] = await Promise.all([
      Company.list("-created_date"),
      User.me().catch(() => null)
    ]);
    
    setCompanies(companiesData);
    setCurrentUser(user);
    setIsLoading(false);
  };

  const filterCompanies = () => {
    let filtered = companies;

    if (searchTerm) {
      filtered = filtered.filter(company =>
        company.company_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        company.company_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        company.contact_person?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (typeFilter !== "all") {
      filtered = filtered.filter(company => company.company_type === typeFilter);
    }

    setFilteredCompanies(filtered);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Check for duplicate company code
    const isDuplicate = companies.some(company => 
      company.company_code.toLowerCase() === formData.company_code.toLowerCase() &&
      company.id !== editingCompany?.id
    );

    if (isDuplicate) {
      alert("Company code already exists. Please use a different code.");
      return;
    }

    if (editingCompany) {
      await Company.update(editingCompany.id, formData);
    } else {
      await Company.create(formData);
    }

    resetForm();
    loadData();
  };

  const resetForm = () => {
    setFormData({
      company_name: "",
      company_code: "",
      contact_person: "",
      phone_number: "",
      email: "",
      address: "",
      city: "",
      state: "",
      pincode: "",
      gst_number: "",
      pan_number: "",
      company_type: "client",
      is_active: true,
      credit_limit: 0,
      payment_terms: "",
      notes: ""
    });
    setShowForm(false);
    setEditingCompany(null);
  };

  const editCompany = (company) => {
    setFormData(company);
    setEditingCompany(company);
    setShowForm(true);
  };

  const deleteCompany = async (companyId) => {
    await Company.delete(companyId);
    loadData();
  };

  const toggleCompanyStatus = async (company) => {
    await Company.update(company.id, { ...company, is_active: !company.is_active });
    loadData();
  };

  const getCompanyTypeBadge = (type) => {
    const typeConfig = {
      client: { color: "bg-blue-100 text-blue-800", label: "Client" },
      vendor: { color: "bg-green-100 text-green-800", label: "Vendor" },
      transport: { color: "bg-purple-100 text-purple-800", label: "Transport" },
      other: { color: "bg-gray-100 text-gray-800", label: "Other" }
    };
    
    const config = typeConfig[type] || typeConfig.other;
    return <Badge className={config.color}>{config.label}</Badge>;
  };

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Company Master</h1>
            <p className="text-slate-600 mt-1">Manage company information and contacts</p>
          </div>
          <Button 
            onClick={() => setShowForm(!showForm)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            {editingCompany ? 'Edit Company' : 'Add Company'}
          </Button>
        </div>

        {/* Search and Filter */}
        <Card className="shadow-sm mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Search & Filter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <Input
                  placeholder="Search companies..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="client">Client</SelectItem>
                  <SelectItem value="vendor">Vendor</SelectItem>
                  <SelectItem value="transport">Transport</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("");
                  setTypeFilter("all");
                }}
              >
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Company Form */}
        {showForm && (
          <Card className="shadow-sm mb-8">
            <CardHeader>
              <CardTitle>{editingCompany ? 'Edit Company' : 'Add New Company'}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Basic Information */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Basic Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>Company Name *</Label>
                      <Input
                        value={formData.company_name}
                        onChange={(e) => setFormData({...formData, company_name: e.target.value})}
                        required
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Company Code *</Label>
                      <Input
                        value={formData.company_code}
                        onChange={(e) => setFormData({...formData, company_code: e.target.value})}
                        required
                        className="mt-1"
                        placeholder="Unique code"
                      />
                    </div>
                    <div>
                      <Label>Contact Person</Label>
                      <Input
                        value={formData.contact_person}
                        onChange={(e) => setFormData({...formData, contact_person: e.target.value})}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Company Type</Label>
                      <Select 
                        value={formData.company_type} 
                        onValueChange={(value) => setFormData({...formData, company_type: value})}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="client">Client</SelectItem>
                          <SelectItem value="vendor">Vendor</SelectItem>
                          <SelectItem value="transport">Transport</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Contact Information */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>Phone Number</Label>
                      <Input
                        value={formData.phone_number}
                        onChange={(e) => setFormData({...formData, phone_number: e.target.value})}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Email</Label>
                      <Input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        className="mt-1"
                      />
                    </div>
                  </div>
                </div>

                {/* Address Information */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Address Information</h3>
                  <div className="space-y-4">
                    <div>
                      <Label>Address</Label>
                      <Textarea
                        value={formData.address}
                        onChange={(e) => setFormData({...formData, address: e.target.value})}
                        className="mt-1"
                      />
                    </div>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <Label>City</Label>
                        <Input
                          value={formData.city}
                          onChange={(e) => setFormData({...formData, city: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label>State</Label>
                        <Input
                          value={formData.state}
                          onChange={(e) => setFormData({...formData, state: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label>PIN Code</Label>
                        <Input
                          value={formData.pincode}
                          onChange={(e) => setFormData({...formData, pincode: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Business Information */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Business Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>GST Number</Label>
                      <Input
                        value={formData.gst_number}
                        onChange={(e) => setFormData({...formData, gst_number: e.target.value})}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>PAN Number</Label>
                      <Input
                        value={formData.pan_number}
                        onChange={(e) => setFormData({...formData, pan_number: e.target.value})}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Credit Limit</Label>
                      <Input
                        type="number"
                        value={formData.credit_limit}
                        onChange={(e) => setFormData({...formData, credit_limit: parseFloat(e.target.value) || 0})}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Payment Terms</Label>
                      <Input
                        value={formData.payment_terms}
                        onChange={(e) => setFormData({...formData, payment_terms: e.target.value})}
                        className="mt-1"
                        placeholder="e.g., 30 days, COD"
                      />
                    </div>
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <Label>Notes</Label>
                  <Textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    className="mt-1"
                    placeholder="Additional notes..."
                  />
                </div>

                <div className="flex justify-end gap-3">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Cancel
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingCompany ? 'Update Company' : 'Add Company'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Companies List */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="w-5 h-5" />
              Companies ({filteredCompanies.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="text-slate-500 mt-4">Loading companies...</p>
              </div>
            ) : filteredCompanies.length === 0 ? (
              <div className="text-center py-8">
                <Building2 className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No companies found</p>
                <p className="text-sm text-slate-400">Add your first company to get started</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {filteredCompanies.map((company) => (
                  <div key={company.id} className="p-4 border rounded-lg hover:bg-slate-50 transition-colors">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-slate-900">{company.company_name}</h3>
                          {getCompanyTypeBadge(company.company_type)}
                          <Badge 
                            className={company.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
                          >
                            {company.is_active ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-600">Code: {company.company_code}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => editCompany(company)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggleCompanyStatus(company)}
                          className={company.is_active ? "text-orange-500" : "text-green-500"}
                        >
                          {company.is_active ? "Deactivate" : "Activate"}
                        </Button>
                        {currentUser && currentUser.role === 'admin' && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-700">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Company</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete {company.company_name}. This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => deleteCompany(company.id)}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  Delete Company
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                      {company.contact_person && (
                        <div className="flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-slate-400" />
                          <span>{company.contact_person}</span>
                        </div>
                      )}
                      {company.phone_number && (
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-slate-400" />
                          <span>{company.phone_number}</span>
                        </div>
                      )}
                      {company.email && (
                        <div className="flex items-center gap-2">
                          <Mail className="w-4 h-4 text-slate-400" />
                          <span>{company.email}</span>
                        </div>
                      )}
                      {company.city && (
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-slate-400" />
                          <span>{company.city}, {company.state}</span>
                        </div>
                      )}
                      {company.credit_limit > 0 && (
                        <div className="flex items-center gap-2">
                          <CreditCard className="w-4 h-4 text-slate-400" />
                          <span>Credit: ₹{company.credit_limit}</span>
                        </div>
                      )}
                      {company.payment_terms && (
                        <div className="flex items-center gap-2">
                          <span className="text-slate-400">Terms:</span>
                          <span>{company.payment_terms}</span>
                        </div>
                      )}
                    </div>

                    {company.notes && (
                      <div className="mt-3 p-3 bg-slate-100 rounded text-sm">
                        <span className="font-medium">Notes: </span>
                        {company.notes}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}