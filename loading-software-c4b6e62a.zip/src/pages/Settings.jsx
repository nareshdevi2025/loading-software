
import React, { useState, useEffect } from "react";
import { LoadingOptions } from "@/api/entities";
import { User } from "@/api/entities"; // Added User import
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Settings, Plus, Trash2, Building2, Truck, UserCheck, Package } from "lucide-react";

export default function SettingsPage() {
  const [options, setOptions] = useState({
    party: [],
    vehicle: [],
    supervisor: [],
    product: []
  });
  const [newValues, setNewValues] = useState({
    party: "",
    vehicle: "",
    supervisor: "",
    product: ""
  });
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null); // Added currentUser state

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      // Fetch options and user data concurrently
      const [allOptions, user] = await Promise.all([
        LoadingOptions.list(),
        User.me().catch(() => null) // Handle potential error if user not found/logged in
      ]);

      setOptions({
        party: allOptions.filter(opt => opt.option_type === "party"),
        vehicle: allOptions.filter(opt => opt.option_type === "vehicle"),
        supervisor: allOptions.filter(opt => opt.option_type === "supervisor"),
        product: allOptions.filter(opt => opt.option_type === "product")
      });
      setCurrentUser(user); // Set current user
      setIsLoading(false);
    };

    fetchData(); // Call the new fetchData function
  }, []);

  // Renamed loadOptions to refreshOptions, now only refreshes options data
  const refreshOptions = async () => {
    const allOptions = await LoadingOptions.list();
    setOptions({
      party: allOptions.filter(opt => opt.option_type === "party"),
      vehicle: allOptions.filter(opt => opt.option_type === "vehicle"),
      supervisor: allOptions.filter(opt => opt.option_type === "supervisor"),
      product: allOptions.filter(opt => opt.option_type === "product")
    });
  };

  const addOption = async (type) => {
    const value = newValues[type].trim();
    if (!value) return;

    // Prevent adding duplicates (case-insensitive check)
    const isDuplicate = options[type].some(
      (option) => option.option_value.toLowerCase() === value.toLowerCase()
    );

    if (isDuplicate) {
      alert(`The option "${value}" already exists and cannot be added again.`); // User feedback for duplicates
      return;
    }

    await LoadingOptions.create({
      option_type: type,
      option_value: value,
      is_active: true
    });

    setNewValues({ ...newValues, [type]: "" });
    refreshOptions(); // Call refreshOptions
  };

  const removeOption = async (option) => {
    await LoadingOptions.delete(option.id);
    refreshOptions(); // Call refreshOptions
  };

  const optionTypes = [
    {
      key: "party",
      title: "Parties/Clients",
      icon: Building2,
      color: "blue",
      description: "Manage party and client names"
    },
    {
      key: "vehicle",
      title: "Vehicle Numbers",
      icon: Truck,
      color: "green",
      description: "Manage vehicle registration numbers"
    },
    {
      key: "supervisor",
      title: "Supervisors",
      icon: UserCheck,
      color: "purple",
      description: "Manage loading supervisor names"
    },
    {
      key: "product",
      title: "Products",
      icon: Package,
      color: "orange",
      description: "Manage product names"
    }
  ];

  const colorClasses = {
    blue: "text-blue-600 bg-blue-50",
    green: "text-green-600 bg-green-50",
    purple: "text-purple-600 bg-purple-50",
    orange: "text-orange-600 bg-orange-50"
  };

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Settings</h1>
          <p className="text-slate-600">Manage dropdown options for loading forms</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {optionTypes.map((type) => (
            <Card key={type.key} className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className={`p-2 rounded-lg ${colorClasses[type.color]}`}>
                    <type.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <span>{type.title}</span>
                    <p className="text-sm font-normal text-slate-600">{type.description}</p>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    // Updated placeholder text
                    placeholder={`Add new ${type.key.replace('_', ' ')}...`} 
                    value={newValues[type.key]}
                    onChange={(e) => setNewValues({ ...newValues, [type.key]: e.target.value })}
                    onKeyPress={(e) => e.key === "Enter" && addOption(type.key)}
                  />
                  <Button 
                    onClick={() => addOption(type.key)}
                    disabled={!newValues[type.key].trim()}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>

                {isLoading ? (
                  <div className="space-y-2">
                    {Array(3).fill(0).map((_, i) => (
                      <div key={i} className="h-8 bg-slate-200 rounded animate-pulse"></div>
                    ))}
                  </div>
                ) : options[type.key].length === 0 ? (
                  <div className="text-center py-6 text-slate-500">
                    <type.icon className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    <p>No {type.title.toLowerCase()} added yet</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {options[type.key].map((option) => (
                      <div key={option.id} className="flex items-center justify-between p-2 border rounded-lg bg-slate-50">
                        <span className="font-medium">{option.option_value}</span>
                        {/* Conditional rendering for Trash2 button: only for admin users */}
                        {currentUser && currentUser.role === 'admin' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeOption(option)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                <div className="text-sm text-slate-600 pt-2 border-t">
                  Total: {options[type.key].length} {type.title.toLowerCase()}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
