import React, { useState, useEffect } from "react";
import { LoadingPlan } from "@/api/entities";
import { LoadingOptions } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Plus, Trash2, Edit, CheckCircle, AlertCircle } from "lucide-react";
import { format } from "date-fns";

export default function LoadingPlanningPage() {
  const [plans, setPlans] = useState([]);
  const [options, setOptions] = useState({
    parties: [],
    vehicles: [],
    products: []
  });
  const [showForm, setShowForm] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [formData, setFormData] = useState({
    party_name: "",
    vehicle_number: "",
    planned_date: format(new Date(), 'yyyy-MM-dd'),
    planned_time: "09:00",
    planned_products: [],
    estimated_duration: 60,
    priority: "medium",
    notes: ""
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    const [plansData, optionsData] = await Promise.all([
      LoadingPlan.list("-created_date"),
      LoadingOptions.list()
    ]);
    
    setPlans(plansData);
    setOptions({
      parties: optionsData.filter(opt => opt.option_type === "party" && opt.is_active),
      vehicles: optionsData.filter(opt => opt.option_type === "vehicle" && opt.is_active),
      products: optionsData.filter(opt => opt.option_type === "product" && opt.is_active)
    });
    setIsLoading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const planData = {
      ...formData,
      plan_id: `PLN-${Date.now()}`,
      status: "planned"
    };

    if (editingPlan) {
      await LoadingPlan.update(editingPlan.id, planData);
    } else {
      await LoadingPlan.create(planData);
    }

    resetForm();
    loadData();
  };

  const resetForm = () => {
    setFormData({
      party_name: "",
      vehicle_number: "",
      planned_date: format(new Date(), 'yyyy-MM-dd'),
      planned_time: "09:00",
      planned_products: [],
      estimated_duration: 60,
      priority: "medium",
      notes: ""
    });
    setShowForm(false);
    setEditingPlan(null);
  };

  const editPlan = (plan) => {
    setFormData(plan);
    setEditingPlan(plan);
    setShowForm(true);
  };

  const deletePlan = async (planId) => {
    await LoadingPlan.delete(planId);
    loadData();
  };

  const addProduct = () => {
    setFormData({
      ...formData,
      planned_products: [...formData.planned_products, {
        product_name: "",
        planned_quantity: 0,
        unit: "pcs"
      }]
    });
  };

  const updateProduct = (index, field, value) => {
    const newProducts = [...formData.planned_products];
    newProducts[index] = { ...newProducts[index], [field]: value };
    setFormData({ ...formData, planned_products: newProducts });
  };

  const removeProduct = (index) => {
    const newProducts = formData.planned_products.filter((_, i) => i !== index);
    setFormData({ ...formData, planned_products: newProducts });
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      planned: { color: "bg-blue-100 text-blue-800", icon: Calendar },
      in_progress: { color: "bg-orange-100 text-orange-800", icon: Clock },
      completed: { color: "bg-green-100 text-green-800", icon: CheckCircle },
      cancelled: { color: "bg-red-100 text-red-800", icon: AlertCircle }
    };
    const config = statusConfig[status] || statusConfig.planned;
    const Icon = config.icon;
    
    return (
      <Badge className={`${config.color} flex items-center gap-1`}>
        <Icon className="w-3 h-3" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const getPriorityColor = (priority) => {
    const colors = {
      low: "border-l-blue-500",
      medium: "border-l-yellow-500",
      high: "border-l-red-500"
    };
    return colors[priority] || colors.medium;
  };

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Loading Planning</h1>
            <p className="text-slate-600 mt-1">Plan and schedule your loading operations</p>
          </div>
          <Button 
            onClick={() => setShowForm(!showForm)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            {editingPlan ? 'Edit Plan' : 'New Plan'}
          </Button>
        </div>

        {showForm && (
          <Card className="shadow-sm mb-8">
            <CardHeader>
              <CardTitle>{editingPlan ? 'Edit Loading Plan' : 'Create Loading Plan'}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label>Party Name *</Label>
                    <Select 
                      value={formData.party_name} 
                      onValueChange={(value) => setFormData({...formData, party_name: value})}
                      required
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Select party" />
                      </SelectTrigger>
                      <SelectContent>
                        {options.parties.map((party) => (
                          <SelectItem key={party.id} value={party.option_value}>
                            {party.option_value}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Vehicle Number *</Label>
                    <Select 
                      value={formData.vehicle_number} 
                      onValueChange={(value) => setFormData({...formData, vehicle_number: value})}
                      required
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Select vehicle" />
                      </SelectTrigger>
                      <SelectContent>
                        {options.vehicles.map((vehicle) => (
                          <SelectItem key={vehicle.id} value={vehicle.option_value}>
                            {vehicle.option_value}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Planned Date *</Label>
                    <Input
                      type="date"
                      value={formData.planned_date}
                      onChange={(e) => setFormData({...formData, planned_date: e.target.value})}
                      className="mt-1"
                      required
                    />
                  </div>

                  <div>
                    <Label>Planned Time</Label>
                    <Input
                      type="time"
                      value={formData.planned_time}
                      onChange={(e) => setFormData({...formData, planned_time: e.target.value})}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label>Estimated Duration (minutes)</Label>
                    <Input
                      type="number"
                      min="15"
                      value={formData.estimated_duration}
                      onChange={(e) => setFormData({...formData, estimated_duration: parseInt(e.target.value)})}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label>Priority</Label>
                    <Select 
                      value={formData.priority} 
                      onValueChange={(value) => setFormData({...formData, priority: value})}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low Priority</SelectItem>
                        <SelectItem value="medium">Medium Priority</SelectItem>
                        <SelectItem value="high">High Priority</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Products Section */}
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <Label className="text-lg font-semibold">Planned Products</Label>
                    <Button type="button" variant="outline" size="sm" onClick={addProduct}>
                      <Plus className="w-4 h-4 mr-1" />
                      Add Product
                    </Button>
                  </div>

                  {formData.planned_products.length === 0 ? (
                    <div className="text-center py-6 text-slate-500 border-2 border-dashed border-slate-200 rounded-lg">
                      <p>No products planned yet</p>
                      <p className="text-sm">Click "Add Product" to start</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {formData.planned_products.map((product, index) => (
                        <div key={index} className="grid md:grid-cols-4 gap-4 p-4 border rounded-lg bg-slate-50">
                          <div>
                            <Label className="text-sm">Product</Label>
                            <Select 
                              value={product.product_name} 
                              onValueChange={(value) => updateProduct(index, "product_name", value)}
                            >
                              <SelectTrigger className="mt-1">
                                <SelectValue placeholder="Select product" />
                              </SelectTrigger>
                              <SelectContent>
                                {options.products.map((prod) => (
                                  <SelectItem key={prod.id} value={prod.option_value}>
                                    {prod.option_value}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label className="text-sm">Planned Quantity</Label>
                            <Input
                              type="number"
                              min="0"
                              value={product.planned_quantity}
                              onChange={(e) => updateProduct(index, "planned_quantity", parseInt(e.target.value) || 0)}
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <Label className="text-sm">Unit</Label>
                            <Select 
                              value={product.unit} 
                              onValueChange={(value) => updateProduct(index, "unit", value)}
                            >
                              <SelectTrigger className="mt-1">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pcs">Pieces</SelectItem>
                                <SelectItem value="kg">Kilograms</SelectItem>
                                <SelectItem value="tons">Tons</SelectItem>
                                <SelectItem value="boxes">Boxes</SelectItem>
                                <SelectItem value="pallets">Pallets</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex items-end">
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              onClick={() => removeProduct(index)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <Label>Notes</Label>
                  <Textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    placeholder="Add planning notes..."
                    className="mt-1"
                  />
                </div>

                <div className="flex justify-end gap-3">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Cancel
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    {editingPlan ? 'Update Plan' : 'Create Plan'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Plans List */}
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Loading Plans</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="text-slate-500 mt-4">Loading plans...</p>
              </div>
            ) : plans.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No loading plans created yet</p>
                <p className="text-sm text-slate-400">Create your first plan to get started</p>
              </div>
            ) : (
              <div className="space-y-4">
                {plans.map((plan) => (
                  <div key={plan.id} className={`p-4 border-l-4 border rounded-lg bg-white ${getPriorityColor(plan.priority)}`}>
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-slate-900">{plan.party_name}</h3>
                          {getStatusBadge(plan.status)}
                          <Badge variant="outline" className="text-xs">
                            {plan.priority} priority
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-600">
                          Vehicle: {plan.vehicle_number} • Plan ID: {plan.plan_id}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => editPlan(plan)}
                          disabled={plan.status === "completed"}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deletePlan(plan.id)}
                          className="text-red-500 hover:text-red-700"
                          disabled={plan.status === "in_progress"}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-4 gap-4 text-sm mb-4">
                      <div>
                        <span className="text-slate-500">Planned Date:</span>
                        <p className="font-medium">{format(new Date(plan.planned_date), "dd MMM yyyy")}</p>
                      </div>
                      <div>
                        <span className="text-slate-500">Planned Time:</span>
                        <p className="font-medium">{plan.planned_time}</p>
                      </div>
                      <div>
                        <span className="text-slate-500">Est. Duration:</span>
                        <p className="font-medium">{plan.estimated_duration} min</p>
                      </div>
                      <div>
                        <span className="text-slate-500">Products:</span>
                        <p className="font-medium">{plan.planned_products?.length || 0} items</p>
                      </div>
                    </div>

                    {plan.planned_products && plan.planned_products.length > 0 && (
                      <div className="mt-4 p-3 bg-slate-50 rounded">
                        <h4 className="font-medium mb-2">Planned Products:</h4>
                        <div className="flex flex-wrap gap-2">
                          {plan.planned_products.map((product, index) => (
                            <span key={index} className="text-xs bg-white px-2 py-1 rounded border">
                              {product.product_name}: {product.planned_quantity} {product.unit}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {plan.notes && (
                      <div className="mt-3 p-3 bg-blue-50 rounded text-sm">
                        <span className="font-medium">Notes: </span>
                        {plan.notes}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}