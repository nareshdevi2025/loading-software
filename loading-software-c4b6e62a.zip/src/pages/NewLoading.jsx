import React, { useState, useEffect } from "react";
import { LoadingSession } from "@/api/entities";
import { LoadingOptions } from "@/api/entities";
import { LoadingPlan } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calendar } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

import LoadingTimer from "../components/loading/LoadingTimer";
import PartyVehicleForm from "../components/loading/PartyVehicleForm";
import ProductsForm from "../components/loading/ProductsForm";
import PalletsForm from "../components/loading/PalletsForm";
import SupervisorsForm from "../components/loading/SupervisorsForm";
import SessionSummary from "../components/loading/SessionSummary";

export default function NewLoading() {
  const navigate = useNavigate();
  const [session, setSession] = useState({
    party_name: "",
    vehicle_number: "",
    loading_persons_count: 1,
    products: [],
    pallets: [],
    supervisors: [],
    status: "not_started",
    notes: ""
  });
  const [options, setOptions] = useState({
    parties: [],
    vehicles: [],
    supervisors: [],
    products: []
  });
  const [plans, setPlans] = useState([]);
  const [selectedPlan, setSelectedPlan] = useState("");
  const [currentStep, setCurrentStep] = useState(1);
  const [sessionId, setSessionId] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [allOptions, allPlans] = await Promise.all([
      LoadingOptions.list(),
      LoadingPlan.list()
    ]);
    
    setOptions({
      parties: allOptions.filter(opt => opt.option_type === "party" && opt.is_active),
      vehicles: allOptions.filter(opt => opt.option_type === "vehicle" && opt.is_active),
      supervisors: allOptions.filter(opt => opt.option_type === "supervisor" && opt.is_active),
      products: allOptions.filter(opt => opt.option_type === "product" && opt.is_active)
    });

    // Filter plans that are scheduled for today or future and not completed
    const availablePlans = allPlans.filter(plan => 
      plan.status === "planned" && 
      new Date(plan.planned_date) >= new Date(new Date().setHours(0,0,0,0))
    );
    setPlans(availablePlans);
  };

  const updateSession = (updates) => {
    setSession(prev => ({ ...prev, ...updates }));
  };

  const loadFromPlan = async (planId) => {
    const plan = plans.find(p => p.id === planId);
    if (plan) {
      updateSession({
        party_name: plan.party_name,
        vehicle_number: plan.vehicle_number,
        products: plan.planned_products.map(p => ({
          product_name: p.product_name,
          total_quantity: p.planned_quantity,
          unit: p.unit,
          status: "pending"
        })),
        notes: plan.notes || ""
      });

      // Update plan status to indicate it's being used
      await LoadingPlan.update(planId, { status: "in_progress" });
      loadData(); // Refresh plans list
    }
  };

  const handleStartLoading = async () => {
    const startTime = new Date().toISOString();
    const newSession = await LoadingSession.create({
      ...session,
      session_id: `LD-${Date.now()}`,
      start_time: startTime,
      status: "in_progress"
    });
    setSessionId(newSession.id);
    updateSession({ status: "in_progress", start_time: startTime });

    // If a plan was selected, mark it as in progress and link it
    if (selectedPlan) {
      const plan = plans.find(p => p.id === selectedPlan);
      if (plan) {
        await LoadingPlan.update(selectedPlan, { 
          status: "in_progress",
          actual_session_id: newSession.id 
        });
      }
    }
  };

  const handleEndLoading = async () => {
    const endTime = new Date();
    const startTime = new Date(session.start_time);
    const duration = Math.round((endTime - startTime) / (1000 * 60));

    await LoadingSession.update(sessionId, {
      end_time: endTime.toISOString(),
      duration_minutes: duration,
      status: "completed"
    });

    // If a plan was used, mark it as completed
    if (selectedPlan) {
      await LoadingPlan.update(selectedPlan, { status: "completed" });
    }

    navigate(createPageUrl("Dashboard"));
  };

  const canStartLoading = session.party_name && session.vehicle_number && session.products.length > 0;

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">New Loading Session</h1>
            <p className="text-slate-600 mt-1">Set up and track your loading operation</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Plan Selection */}
          {plans.length > 0 && session.status === "not_started" && (
            <Card className="shadow-sm border-blue-200 bg-blue-50/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  Load from Existing Plan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4 items-end">
                  <div className="flex-1">
                    <Select 
                      value={selectedPlan} 
                      onValueChange={(value) => {
                        setSelectedPlan(value);
                        if (value) loadFromPlan(value);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a loading plan..." />
                      </SelectTrigger>
                      <SelectContent>
                        {plans.map((plan) => (
                          <SelectItem key={plan.id} value={plan.id}>
                            <div className="flex items-center gap-2">
                              <span>{plan.party_name} - {plan.vehicle_number}</span>
                              <Badge variant="outline" className="text-xs">
                                {format(new Date(plan.planned_date), "MMM d")}
                              </Badge>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {selectedPlan && (
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setSelectedPlan("");
                        updateSession({
                          party_name: "",
                          vehicle_number: "",
                          products: [],
                          notes: ""
                        });
                      }}
                    >
                      Clear Selection
                    </Button>
                  )}
                </div>
                {selectedPlan && (
                  <div className="mt-4 p-3 bg-white rounded border">
                    <p className="text-sm text-green-600 font-medium">
                      ✓ Plan loaded successfully! You can modify details below before starting.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          <LoadingTimer 
            session={session}
            onStart={handleStartLoading}
            onEnd={handleEndLoading}
            canStart={canStartLoading}
          />

          <div className="grid lg:grid-cols-2 gap-6">
            <div className="space-y-6">
              <PartyVehicleForm 
                session={session}
                options={options}
                onUpdate={updateSession}
                disabled={session.status === "in_progress"}
              />

              <ProductsForm 
                session={session}
                options={options}
                onUpdate={updateSession}
                disabled={session.status === "completed"}
              />
            </div>

            <div className="space-y-6">
              <PalletsForm 
                session={session}
                onUpdate={updateSession}
                disabled={session.status === "completed"}
              />

              <SupervisorsForm 
                session={session}
                options={options}
                onUpdate={updateSession}
                disabled={session.status === "completed"}
              />
            </div>
          </div>

          <SessionSummary session={session} onUpdate={updateSession} />
        </div>
      </div>
    </div>
  );
}