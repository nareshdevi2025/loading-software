import React, { useState, useEffect } from "react";
import { LoadingSession } from "@/api/entities";
import { LoadingPlan } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, Clock, Truck, Package, Users, Timer, Calendar, BarChart3 } from "lucide-react";
import { format } from "date-fns";

import ActiveSessions from "../components/dashboard/ActiveSessions";
import StatsOverview from "../components/dashboard/StatsOverview";
import RecentSessions from "../components/dashboard/RecentSessions";

export default function Dashboard() {
  const [sessions, setSessions] = useState([]);
  const [activeSessions, setActiveSessions] = useState([]);
  const [plans, setPlans] = useState([]);
  const [plannedSessions, setPlannedSessions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    const [sessionsData, plansData] = await Promise.all([
      LoadingSession.list("-created_date", 50),
      LoadingPlan.list("-created_date", 20)
    ]);
    
    setSessions(sessionsData);
    setActiveSessions(sessionsData.filter(session => session.status === "in_progress"));
    setPlans(plansData);
    setPlannedSessions(plansData.filter(plan => plan.status === "planned"));
    setIsLoading(false);
  };

  const completedToday = sessions.filter(session => 
    session.status === "completed" && 
    format(new Date(session.created_date), 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd')
  ).length;

  const avgDuration = sessions
    .filter(session => session.duration_minutes)
    .reduce((sum, session) => sum + session.duration_minutes, 0) / 
    (sessions.filter(session => session.duration_minutes).length || 1);

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Loading Dashboard</h1>
            <p className="text-slate-600 mt-1">Monitor and manage your loading operations</p>
          </div>
          <div className="flex gap-3">
            <Link to={createPageUrl("LoadingPlanning")}>
              <Button variant="outline" className="border-blue-200 text-blue-700 hover:bg-blue-50">
                <Calendar className="w-5 h-5 mr-2" />
                Planning
              </Button>
            </Link>
            <Link to={createPageUrl("NewLoading")}>
              <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg">
                <Plus className="w-5 h-5 mr-2" />
                Start New Loading
              </Button>
            </Link>
          </div>
        </div>

        <StatsOverview 
          totalSessions={sessions.length}
          activeSessions={activeSessions.length}
          completedToday={completedToday}
          avgDuration={avgDuration}
          plannedSessions={plannedSessions.length}
          isLoading={isLoading}
        />

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <ActiveSessions 
              sessions={activeSessions}
              onSessionUpdate={loadData}
              isLoading={isLoading}
            />
            
            {/* Planned vs Actual Comparison */}
            {(plannedSessions.length > 0 || activeSessions.length > 0) && (
              <Card className="shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-purple-500" />
                    Planned vs Actual Loading
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Today's planned vs actual */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <p className="text-2xl font-bold text-blue-600">{plannedSessions.length}</p>
                        <p className="text-sm text-slate-600">Planned Sessions</p>
                      </div>
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <p className="text-2xl font-bold text-green-600">{completedToday}</p>
                        <p className="text-sm text-slate-600">Completed Today</p>
                      </div>
                    </div>

                    {/* Performance indicator */}
                    <div className="text-center">
                      <div className="text-lg font-semibold text-slate-900">
                        Performance: {plannedSessions.length > 0 ? Math.round((completedToday / plannedSessions.length) * 100) : 100}%
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-3 mt-2">
                        <div 
                          className="bg-gradient-to-r from-blue-500 to-green-500 h-3 rounded-full transition-all"
                          style={{ width: `${Math.min(100, plannedSessions.length > 0 ? (completedToday / plannedSessions.length) * 100 : 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
          
          <div className="space-y-6">
            <RecentSessions 
              sessions={sessions.slice(0, 10)}
              isLoading={isLoading}
            />

            {/* Upcoming Plans */}
            {plannedSessions.length > 0 && (
              <Card className="shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-blue-500" />
                    Upcoming Plans
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {plannedSessions.slice(0, 5).map((plan) => (
                      <div key={plan.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-slate-50 transition-colors">
                        <div>
                          <p className="font-medium text-slate-900">{plan.party_name}</p>
                          <p className="text-sm text-slate-500">
                            {format(new Date(plan.planned_date), "MMM d")} at {plan.planned_time}
                          </p>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {plan.planned_products?.length || 0} items
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}