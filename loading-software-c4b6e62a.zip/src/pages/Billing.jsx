
import React, { useState, useEffect } from "react";
import { LoadingSession } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Printer, FileText, Truck, User, Package, Clock, History, Receipt } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function BillingPage() {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState([]);
  const [selectedSession, setSelectedSession] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadSessions();
    
    // Check if there's a session ID in URL params
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session');
    if (sessionId) {
      loadSpecificSession(sessionId);
    }
  }, []);

  const loadSessions = async () => {
    setIsLoading(true);
    const completedSessions = await LoadingSession.list("-created_date", 50);
    setSessions(completedSessions.filter(session => session.status === "completed"));
    setIsLoading(false);
  };

  const loadSpecificSession = async (sessionId) => {
    const allSessions = await LoadingSession.list();
    const foundSession = allSessions.find(s => s.id === sessionId);
    if (foundSession) {
      setSelectedSession(foundSession);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const productsGrouped = selectedSession ? selectedSession.pallets.reduce((acc, pallet) => {
    const productName = pallet.product_name || "Unassigned";
    if (!acc[productName]) {
      acc[productName] = {
        pallets: [],
        totalQuantity: 0,
        totalPallets: 0,
        unit: selectedSession.products.find(p => p.product_name === productName)?.unit || 'nos'
      };
    }
    acc[productName].pallets.push(pallet);
    acc[productName].totalQuantity += pallet.quantity || 0;
    acc[productName].totalPallets += 1;
    return acc;
  }, {}) : {};

  if (isLoading) {
    return (
      <div className="p-4 md:p-8 bg-slate-50 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-slate-500 mt-4">Loading billing data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8 no-print">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Billing & Reports</h1>
            <p className="text-slate-600 mt-1">View completed loading session details and generate bills</p>
          </div>
          {selectedSession && (
            <div className="flex gap-3">
              <Button 
                variant="outline"
                onClick={() => setSelectedSession(null)}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to List
              </Button>
              <Button onClick={handlePrint} className="bg-blue-600 hover:bg-blue-700">
                <Printer className="w-4 h-4 mr-2" />
                Print Bill
              </Button>
            </div>
          )}
        </div>

        {!selectedSession ? (
          /* Session List View */
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-blue-600" />
                Completed Loading Sessions
              </CardTitle>
            </CardHeader>
            <CardContent>
              {sessions.length === 0 ? (
                <div className="text-center py-8">
                  <Receipt className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">No completed sessions found</p>
                  <p className="text-sm text-slate-400">Complete loading sessions will appear here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {sessions.map((session) => (
                    <div 
                      key={session.id} 
                      className="p-4 border rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
                      onClick={() => setSelectedSession(session)}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-slate-900">{session.party_name}</h3>
                            <Badge className="bg-green-100 text-green-800">Completed</Badge>
                          </div>
                          <p className="text-sm text-slate-600">
                            Session: {session.session_id} • Vehicle: {session.vehicle_number}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-slate-600">
                            {format(new Date(session.end_time || session.created_date), "MMM d, yyyy")}
                          </p>
                          <p className="text-sm text-slate-500">
                            {format(new Date(session.end_time || session.created_date), "HH:mm")}
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-slate-500">Products:</span>
                          <span className="ml-2 font-medium">{session.products?.length || 0}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Pallets:</span>
                          <span className="ml-2 font-medium">{session.pallets?.length || 0}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Duration:</span>
                          <span className="ml-2 font-medium">
                            {session.duration_minutes ? `${session.duration_minutes}m` : "-"}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500">Total Qty:</span>
                          <span className="ml-2 font-medium">
                            {session.pallets?.reduce((sum, pallet) => sum + (pallet.quantity || 0), 0) || 0}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          /* Enhanced Detailed Bill View */
          <Card className="shadow-lg" id="billing-section">
            <CardHeader className="border-b bg-slate-50 p-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-bold text-slate-800">Loading Bill & Report</h2>
                  <p className="text-slate-500">Session ID: {selectedSession.session_id}</p>
                </div>
                <Badge className="bg-green-100 text-green-800 text-base px-4 py-1">Completed</Badge>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              {/* Session Info */}
              <div className="grid md:grid-cols-2 gap-6 border-b pb-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <User className="w-5 h-5 text-slate-500" />
                    <span className="font-medium">Party:</span>
                    <span className="text-slate-800 font-bold">{selectedSession.party_name}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Truck className="w-5 h-5 text-slate-500" />
                    <span className="font-medium">Vehicle:</span>
                    <span className="text-slate-800 font-bold">{selectedSession.vehicle_number}</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-slate-500" />
                    <span className="font-medium">Completed:</span>
                    <span className="text-slate-800 font-bold">
                      {format(new Date(selectedSession.end_time || selectedSession.created_date), "dd MMM yyyy, HH:mm")}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5 text-slate-500" />
                    <span className="font-medium">Duration:</span>
                    <span className="text-slate-800 font-bold">{selectedSession.duration_minutes || 0} minutes</span>
                  </div>
                </div>
              </div>

              {/* Enhanced Billing Details */}
              <div>
                <h3 className="text-xl font-semibold text-slate-800 mb-6">Loaded Items Details</h3>
                <div className="space-y-8">
                  {Object.entries(productsGrouped).map(([productName, data]) => (
                    <div key={productName} className="border rounded-lg p-6 bg-white">
                      {/* Product Header */}
                      <div className="flex justify-between items-center mb-6">
                        <h4 className="font-bold text-xl text-blue-600 flex items-center gap-2">
                          <Package className="w-6 h-6" />
                          {productName}
                        </h4>
                        <div className="text-right">
                          <p className="font-bold text-3xl text-green-600">{data.totalQuantity}</p>
                          <p className="text-sm text-slate-600">{data.unit}</p>
                          <p className="text-xs text-slate-500">({data.totalPallets} pallets)</p>
                        </div>
                      </div>

                      {/* Pallet-wise Breakdown */}
                      <div className="mb-6">
                        <h5 className="font-semibold text-slate-700 text-lg mb-4">Pallet-wise Breakdown:</h5>
                        <div className="space-y-3">
                          {data.pallets.map((pallet, index) => (
                            <div key={index} className="flex justify-between items-center p-4 bg-slate-50 rounded-lg border">
                              <div className="flex items-center gap-4">
                                <span className="font-bold text-blue-600 text-lg">{pallet.pallet_number}:</span>
                                <span className="text-slate-700 font-mono text-lg">
                                  ({pallet.length || 0} × {pallet.width || 0}) = {(pallet.length || 0) * (pallet.width || 0)}
                                  {pallet.loose_quantity > 0 && ` + ${pallet.loose_quantity} = ${pallet.quantity || 0}`}
                                </span>
                              </div>
                              <span className="font-bold text-2xl text-green-600">{pallet.quantity || 0}</span>
                            </div>
                          ))}
                          
                          {/* Total Calculation Row */}
                          {data.pallets.length > 1 && (
                            <div className="flex justify-between items-center p-4 bg-blue-100 rounded-lg border-2 border-blue-300 mt-4">
                              <div className="flex items-center gap-4">
                                <span className="font-bold text-blue-800 text-lg">Total Calculation:</span>
                                <span className="text-blue-800 font-mono text-lg">
                                  {data.pallets.length > 0 && data.pallets[0].length} × {
                                    data.pallets.reduce((sum, p) => sum + (p.width || 0), 0)
                                  } = {
                                    (data.pallets.length > 0 && data.pallets[0].length ? data.pallets[0].length : 0) * 
                                    data.pallets.reduce((sum, p) => sum + (p.width || 0), 0)
                                  }
                                </span>
                              </div>
                              <span className="font-bold text-2xl text-blue-800">{data.totalQuantity}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Product Total Summary */}
                      <div className="p-6 bg-blue-50 border-2 border-blue-200 rounded-lg">
                        <div className="flex justify-between items-center">
                          <div>
                            <span className="font-bold text-blue-800 text-xl">Total for {productName}:</span>
                            <p className="text-blue-600 text-lg">{data.totalPallets} pallets loaded</p>
                          </div>
                          <div className="text-right">
                            <span className="font-bold text-4xl text-blue-800">{data.totalQuantity}</span>
                            <p className="text-blue-600 text-lg">{data.unit}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Grand Total Summary */}
                <div className="mt-8 p-6 bg-green-50 border-2 border-green-200 rounded-lg">
                  <h3 className="text-2xl font-bold text-green-800 mb-4">Grand Total Summary</h3>
                  <div className="grid md:grid-cols-3 gap-6 text-center">
                    <div className="p-4 bg-white rounded-lg border">
                      <p className="text-3xl font-bold text-green-700">
                        {Object.values(productsGrouped).reduce((sum, data) => sum + data.totalPallets, 0)}
                      </p>
                      <p className="text-green-600 font-medium">Total Pallets</p>
                    </div>
                    <div className="p-4 bg-white rounded-lg border">
                      <p className="text-3xl font-bold text-green-700">
                        {Object.values(productsGrouped).reduce((sum, data) => sum + data.totalQuantity, 0)}
                      </p>
                      <p className="text-green-600 font-medium">Total Quantity</p>
                    </div>
                    <div className="p-4 bg-white rounded-lg border">
                      <p className="text-3xl font-bold text-green-700">
                        {Object.keys(productsGrouped).length}
                      </p>
                      <p className="text-green-600 font-medium">Products Loaded</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {selectedSession.notes && (
                <div className="border-t pt-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-2">Additional Notes</h3>
                  <p className="text-slate-600 bg-slate-100 p-3 rounded-md">{selectedSession.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
      
      <style jsx global>{`
        @media print {
          body {
            background-color: #fff;
          }
          
          body * {
            visibility: hidden;
          }
          
          .no-print, .no-print * {
            display: none !important;
          }
          
          #billing-section, #billing-section * {
            visibility: visible;
          }
          
          #billing-section {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 1rem;
            border: none;
            box-shadow: none;
            background-color: #fff;
          }

          @page {
            size: auto;
            margin: 0mm;
          }
        }
      `}</style>
    </div>
  );
}
