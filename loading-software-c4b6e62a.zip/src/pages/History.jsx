
import React, { useState, useEffect } from "react";
import { LoadingSession } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { History, Search, Filter, Calendar, Clock, CheckCircle, Trash2, Download, BarChart3 } from "lucide-react";
import { format, startOfDay, endOfDay } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

import DailyReport from "../components/history/DailyReport";

export default function HistoryPage() {
  const [sessions, setSessions] = useState([]);
  const [filteredSessions, setFilteredSessions] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("");
  const [reportType, setReportType] = useState("all"); // Added report type filter
  const [showReport, setShowReport] = useState(false);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadSessions();
  }, []);

  useEffect(() => {
    filterSessions();
  }, [sessions, searchTerm, statusFilter, dateFilter]);

  const loadSessions = async () => {
    setIsLoading(true);
    const data = await LoadingSession.list("-created_date", 200);
    setSessions(data);
    setIsLoading(false);
  };

  const deleteSession = async (sessionId) => {
    try {
      await LoadingSession.delete(sessionId);
      const updatedSessions = sessions.filter(s => s.id !== sessionId);
      setSessions(updatedSessions);
    } catch (error) {
      console.error('Error deleting session:', error);
    }
  };

  const filterSessions = () => {
    let filtered = sessions;

    if (searchTerm) {
      filtered = filtered.filter(session =>
        session.party_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.vehicle_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.session_id?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(session => session.status === statusFilter);
    }

    if (dateFilter) {
      const filterDate = new Date(dateFilter);
      filtered = filtered.filter(session => {
        const sessionDate = new Date(session.created_date);
        return format(sessionDate, 'yyyy-MM-dd') === format(filterDate, 'yyyy-MM-dd');
      });
    }

    setFilteredSessions(filtered);
  };

  const exportToCsv = () => {
    const csvHeaders = [
      'Date', 'Session ID', 'Party Name', 'Vehicle Number',
      'Status', 'Duration (min)', 'Products Count', 'Pallets Count', 'Total Quantity'
    ];

    const csvData = filteredSessions.map(session => [
      format(new Date(session.created_date), 'yyyy-MM-dd HH:mm'),
      session.session_id || '',
      session.party_name || '',
      session.vehicle_number || '',
      session.status || '',
      session.duration_minutes || 0,
      session.products?.length || 0,
      session.pallets?.length || 0,
      session.pallets?.reduce((sum, pallet) => sum + (pallet.quantity || 0), 0) || 0
    ]);

    const csvContent = [csvHeaders, ...csvData]
      .map(row => row.map(field => `"${field}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `loading-history-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
  };

  // Weekly Report Function
  const generateWeeklyReport = () => {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const weeklyData = sessions.filter(session =>
      new Date(session.created_date) >= oneWeekAgo
    );

    const csvHeaders = ['WEEKLY REPORT - ' + format(new Date(), 'dd MMM yyyy'), '', '', '', '', '', '', '', ''];
    const summaryHeaders = ['Metric', 'Value'];
    const summary = [
      ['Total Sessions This Week', weeklyData.length],
      ['Completed Sessions', weeklyData.filter(s => s.status === 'completed').length],
      ['Total Duration (minutes)', weeklyData.reduce((sum, s) => sum + (s.duration_minutes || 0), 0)],
      ['Total Pallets', weeklyData.reduce((sum, s) => sum + (s.pallets?.length || 0), 0)],
      ['Total Quantity', weeklyData.reduce((sum, s) => sum + (s.pallets?.reduce((ps, p) => ps + (p.quantity || 0), 0) || 0), 0)]
    ];

    const detailHeaders = ['Date', 'Session ID', 'Party', 'Vehicle', 'Status', 'Duration', 'Products', 'Pallets', 'Quantity'];
    const details = weeklyData.map(session => [
      format(new Date(session.created_date), 'dd MMM yyyy HH:mm'),
      session.session_id || '',
      session.party_name || '',
      session.vehicle_number || '',
      session.status || '',
      session.duration_minutes || 0,
      session.products?.length || 0,
      session.pallets?.length || 0,
      session.pallets?.reduce((sum, p) => sum + (p.quantity || 0), 0) || 0
    ]);

    const csvContent = [
      csvHeaders,
      [''],
      summaryHeaders,
      ...summary,
      [''],
      detailHeaders,
      ...details
    ].map(row => Array.isArray(row) ? row.map(field => `"${field}"`).join(',') : `"${row}"`).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `weekly-report-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
  };

  // Monthly Report Function
  const generateMonthlyReport = () => {
    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);

    const monthlyData = sessions.filter(session =>
      new Date(session.created_date) >= oneMonthAgo
    );

    const csvHeaders = ['MONTHLY REPORT - ' + format(new Date(), 'dd MMM yyyy'), '', '', '', '', '', '', '', ''];
    const summaryHeaders = ['Metric', 'Value'];
    const summary = [
      ['Total Sessions This Month', monthlyData.length],
      ['Completed Sessions', monthlyData.filter(s => s.status === 'completed').length],
      ['Total Duration (minutes)', monthlyData.reduce((sum, s) => sum + (s.duration_minutes || 0), 0)],
      ['Total Pallets', monthlyData.reduce((sum, s) => sum + (s.pallets?.length || 0), 0)],
      ['Total Quantity', monthlyData.reduce((sum, s) => sum + (s.pallets?.reduce((ps, p) => ps + (p.quantity || 0), 0) || 0), 0)],
      ['Average Session Duration', Math.round(monthlyData.reduce((sum, s) => sum + (s.duration_minutes || 0), 0) / (monthlyData.length || 1))]
    ];

    const detailHeaders = ['Date', 'Session ID', 'Party', 'Vehicle', 'Status', 'Duration', 'Products', 'Pallets', 'Quantity'];
    const details = monthlyData.map(session => [
      format(new Date(session.created_date), 'dd MMM yyyy HH:mm'),
      session.session_id || '',
      session.party_name || '',
      session.vehicle_number || '',
      session.status || '',
      session.duration_minutes || 0,
      session.products?.length || 0,
      session.pallets?.length || 0,
      session.pallets?.reduce((sum, p) => sum + (p.quantity || 0), 0) || 0
    ]);

    const csvContent = [
      csvHeaders,
      [''],
      summaryHeaders,
      ...summary,
      [''],
      detailHeaders,
      ...details
    ].map(row => Array.isArray(row) ? row.map(field => `"${field}"`).join(',') : `"${row}"`).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `monthly-report-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "in_progress":
        return <Clock className="w-4 h-4 text-orange-500" />;
      default:
        return <Calendar className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case "in_progress":
        return <Badge className="bg-orange-100 text-orange-800">In Progress</Badge>;
      default:
        return <Badge variant="secondary">Not Started</Badge>;
    }
  };

  if (showReport) {
    return (
      <DailyReport
        selectedDate={selectedDate}
        onDateChange={setSelectedDate}
        onBack={() => setShowReport(false)}
        sessions={sessions}
      />
    );
  }

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Loading History</h1>
            <p className="text-slate-600">View and manage all loading sessions</p>
          </div>
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setShowReport(true)}
              className="border-blue-200 text-blue-700 hover:bg-blue-50"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Daily Reports
            </Button>
            <Button
              variant="outline"
              onClick={generateWeeklyReport}
              disabled={sessions.length === 0}
              className="border-green-200 text-green-700 hover:bg-green-50"
            >
              <Download className="w-4 h-4 mr-2" />
              Weekly Report
            </Button>
            <Button
              variant="outline"
              onClick={generateMonthlyReport}
              disabled={sessions.length === 0}
              className="border-purple-200 text-purple-700 hover:bg-purple-50"
            >
              <Download className="w-4 h-4 mr-2" />
              Monthly Report
            </Button>
            <Button
              variant="outline"
              onClick={exportToCsv}
              disabled={filteredSessions.length === 0}
            >
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>

        <Card className="shadow-sm mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <Input
                  placeholder="Search by party, vehicle, or session ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="not_started">Not Started</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                placeholder="Filter by date"
              />
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("");
                  setStatusFilter("all");
                  setDateFilter("");
                }}
              >
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center gap-2">
                <History className="w-5 h-5" />
                Sessions ({filteredSessions.length})
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="text-slate-500 mt-4">Loading sessions...</p>
              </div>
            ) : filteredSessions.length === 0 ? (
              <div className="text-center py-8">
                <History className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No sessions found</p>
                <p className="text-sm text-slate-400">Try adjusting your search filters</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredSessions.map((session) => (
                  <div key={session.id} className="p-4 border rounded-lg hover:bg-slate-50 transition-colors">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                          {getStatusIcon(session.status)}
                          <h3 className="font-semibold text-slate-900">{session.party_name}</h3>
                          {getStatusBadge(session.status)}
                        </div>
                        <p className="text-sm text-slate-600">
                          Session: {session.session_id} • Vehicle: {session.vehicle_number}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <p className="text-sm text-slate-600">
                            {format(new Date(session.created_date), "MMM d, yyyy")}
                          </p>
                          <p className="text-sm text-slate-500">
                            {format(new Date(session.created_date), "HH:mm")}
                          </p>
                        </div>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-700">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Session</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently delete the loading session for {session.party_name}. This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteSession(session.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Delete Session
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-slate-500">Products:</span>
                        <span className="ml-2 font-medium">{session.products?.length || 0}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Pallets:</span>
                        <span className="ml-2 font-medium">{session.pallets?.length || 0}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Duration:</span>
                        <span className="ml-2 font-medium">
                          {session.duration_minutes ? `${session.duration_minutes}m` : "-"}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500">Total Qty:</span>
                        <span className="ml-2 font-medium">
                          {session.pallets?.reduce((sum, pallet) => sum + (pallet.quantity || 0), 0) || 0}
                        </span>
                      </div>
                    </div>

                    {session.notes && (
                      <div className="mt-3 p-3 bg-slate-100 rounded text-sm">
                        <span className="font-medium">Notes: </span>
                        {session.notes}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
